package au.edu.sydney.soft3202.s1y2021.task1;

public class Main {
    public static void main(String[] args) {
        EnrolmentSystem e = new EnrolmentSystem();

        Student bob = e.addStudent("123456789", "jbur2821", "Bob", "Bobby");
        Student fred = e.addStudent("456789123", "jbur2822", "Fred", "Freddy");
        Student frank = e.addStudent("789123456", "jbur2823", "Frank", null);

        Faculty sci = e.addFaculty("Faculty of Science", "FoS");
        Faculty feng = e.addFaculty("Faculty of Engineering", "FEng");

        Unit info1110 = e.addUnit("INFO1110", "Intro prog", "Faculty of Engineering");
        Unit comp2017 = e.addUnit("COMP2017", "Advanced prog", "Faculty of Engineering");
        Unit phys1001 = e.addUnit("PHYS1001", "Intro physics", "Faculty of Science");

        info1110.enrolStudent(bob);
        info1110.enrolStudent(fred);
        comp2017.enrolStudent(bob);
        phys1001.enrolStudent(bob);
        phys1001.enrolStudent(frank);

        System.out.println(e.getReport());
    }
}
