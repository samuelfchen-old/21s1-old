package au.edu.sydney.hecfor.erp.auth;

/**
 * Stubbed interface (TGR should never touch its methods)
 */
public interface AuthToken {
}
