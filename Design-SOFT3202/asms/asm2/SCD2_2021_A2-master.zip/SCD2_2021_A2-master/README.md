# SCD2_2021_A2

This is an example repository that matches what the script will expect to see - Note that the build.gradle file is ignored, as are the interfaces. Only the files referenced in the assignment specification are used - all others are ignored.

Make sure you match this folder and package structure PRECISELY or your repository will be rejected.
